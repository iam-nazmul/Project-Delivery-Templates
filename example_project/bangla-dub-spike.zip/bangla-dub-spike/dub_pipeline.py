"""
Spike prototype: offline Bangla dubbing pipeline (pre-process mode).

    video -> audio -> [Demucs] voice + background
          -> [faster-whisper] text + timestamps (English, or translated to English)
          -> [pyannote] who spoke when
          -> [IndicTrans2] English -> Bangla
          -> [Indic Parler-TTS] Bangla voice per speaker
          -> time-fit + mix with background -> <video>.bn.wav (+ .bn.srt, .bn.mkv)

Usage:
    python dub_pipeline.py movie.mp4 --hf-token hf_xxx          # first run, downloads models
    python dub_pipeline.py movie.mp4 --offline                  # later runs, no network

Every stage prints "STAGE: <name>" and its duration, and timings.json is written
so experiment E6 (speed) can be recorded directly.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import soundfile as sf

SR = 44100  # working sample rate for mixing (Parler-TTS outputs 44.1 kHz)

# Six named Bengali voices from the Indic Parler-TTS model card.
# Alternating male / female so speakers A, B, C... are easy to tell apart.
BENGALI_VOICES = ["Arjun", "Aditi", "Tapan", "Rashmi", "Arnav", "Riya"]


@dataclass
class Line:
    start: float
    end: float
    source_text: str
    english: str
    bangla: str = ""
    speaker: str = "SPEAKER_00"
    voice: str = ""
    tts_seconds: float = 0.0
    stretch: float = 1.0
    placed_at: float = 0.0


# --------------------------------------------------------------------------- utils
class Timer:
    def __init__(self):
        self.times: dict[str, float] = {}

    def stage(self, name: str):
        timer = self

        class _Ctx:
            def __enter__(self_inner):
                print(f"STAGE: {name}", flush=True)
                self_inner.t0 = time.perf_counter()

            def __exit__(self_inner, *exc):
                dt = time.perf_counter() - self_inner.t0
                timer.times[name] = round(dt, 2)
                print(f"  done in {dt:.1f}s", flush=True)

        return _Ctx()


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def pick_device() -> str:
    import torch

    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def load_audio(path: Path, sr: int = SR, channels: int = 2) -> np.ndarray:
    """Decode any audio/video file to float32 [samples, channels] via ffmpeg."""
    out = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "f32le", "-ac", str(channels),
         "-ar", str(sr), "-"],
        check=True, stdout=subprocess.PIPE,
    ).stdout
    return np.frombuffer(out, dtype=np.float32).reshape(-1, channels).copy()


def time_stretch(audio: np.ndarray, sr: int, factor: float) -> np.ndarray:
    """Speed audio up by `factor` (>1 = faster) without changing pitch, via ffmpeg atempo."""
    if abs(factor - 1.0) < 0.02:
        return audio
    with tempfile.TemporaryDirectory() as td:
        src, dst = Path(td) / "in.wav", Path(td) / "out.wav"
        sf.write(src, audio, sr)
        filters, f = [], factor
        while f > 2.0:  # atempo is most reliable in 0.5-2.0 steps
            filters.append("atempo=2.0")
            f /= 2.0
        filters.append(f"atempo={f:.4f}")
        run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-filter:a", ",".join(filters), str(dst)])
        out, _ = sf.read(dst, dtype="float32")
    return out


def srt_time(t: float) -> str:
    h, rem = divmod(int(t * 1000), 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


# --------------------------------------------------------------------------- stages
def extract_audio(video: Path, work: Path) -> Path:
    wav = work / "original.wav"
    run(["ffmpeg", "-y", "-v", "error", "-i", str(video), "-vn", "-ac", "2", "-ar", str(SR), str(wav)])
    return wav


def separate(wav: Path, work: Path, device: str) -> tuple[Path, Path]:
    """Demucs two-stem split -> (vocals, background)."""
    dev = "cuda" if device == "cuda" else "cpu"  # Demucs MPS support is patchy
    run([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs",
         "-d", dev, "-o", str(work / "demucs"), str(wav)])
    stem_dir = work / "demucs" / "htdemucs" / wav.stem
    return stem_dir / "vocals.wav", stem_dir / "no_vocals.wav"


def transcribe(vocals: Path, device: str, model_size: str, lang: str | None) -> tuple[list[Line], str]:
    from faster_whisper import WhisperModel

    dev = "cuda" if device == "cuda" else "cpu"  # faster-whisper has no MPS backend
    compute = "float16" if dev == "cuda" else "int8"
    model = WhisperModel(model_size, device=dev, compute_type=compute)

    segs, info = model.transcribe(str(vocals), language=lang, vad_filter=True)
    segs = list(segs)
    detected = info.language
    print(f"  detected language: {detected} (p={info.language_probability:.2f})", flush=True)

    if detected == "en":
        return [Line(s.start, s.end, s.text.strip(), s.text.strip()) for s in segs], detected

    # Pivot: Whisper's built-in translate-to-English, then IndicTrans2 English -> Bangla.
    # Second pass keeps timestamps aligned with what is said.
    tr, _ = model.transcribe(str(vocals), language=detected, task="translate", vad_filter=True)
    lines = [Line(s.start, s.end, "", s.text.strip()) for s in tr]
    for ln in lines:  # attach original-language text by overlap (for review only)
        ln.source_text = " ".join(s.text.strip() for s in segs if s.end > ln.start and s.start < ln.end)
    return lines, detected


def diarize(vocals: Path, lines: list[Line], token: str | None, device: str, num_speakers: int | None) -> None:
    import torch
    from pyannote.audio import Pipeline

    try:
        pipe = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", token=token)
    except TypeError:  # older pyannote versions
        pipe = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token=token)
    if device == "cuda":
        pipe.to(torch.device("cuda"))

    kwargs = {"num_speakers": num_speakers} if num_speakers else {}
    out = pipe(str(vocals), **kwargs)
    ann = getattr(out, "speaker_diarization", out)  # pyannote 4.x wraps the annotation

    turns = [(t.start, t.end, spk) for t, _, spk in ann.itertracks(yield_label=True)]
    for ln in lines:
        overlap: dict[str, float] = {}
        for s, e, spk in turns:
            o = min(e, ln.end) - max(s, ln.start)
            if o > 0:
                overlap[spk] = overlap.get(spk, 0) + o
        if overlap:
            ln.speaker = max(overlap, key=overlap.get)


def translate(lines: list[Line], device: str) -> None:
    import torch
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

    try:
        from IndicTransToolkit.processor import IndicProcessor
    except ImportError:
        from IndicTransToolkit import IndicProcessor

    name = "ai4bharat/indictrans2-en-indic-dist-200M"
    tok = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
    model = AutoModelForSeq2SeqLM.from_pretrained(name, trust_remote_code=True).to(device).eval()
    ip = IndicProcessor(inference=True)

    batch_size = 16
    for i in range(0, len(lines), batch_size):
        chunk = lines[i:i + batch_size]
        batch = ip.preprocess_batch([l.english for l in chunk], src_lang="eng_Latn", tgt_lang="ben_Beng")
        enc = tok(batch, truncation=True, padding="longest", return_tensors="pt",
                  return_attention_mask=True).to(device)
        with torch.no_grad():
            gen = model.generate(**enc, use_cache=True, min_length=0, max_length=256, num_beams=5)
        decoded = tok.batch_decode(gen, skip_special_tokens=True, clean_up_tokenization_spaces=True)
        for ln, bn in zip(chunk, ip.postprocess_batch(decoded, lang="ben_Beng")):
            ln.bangla = bn


def synthesize(lines: list[Line], work: Path, device: str, voice_map: dict[str, str]) -> list[Path]:
    import torch
    from parler_tts import ParlerTTSForConditionalGeneration
    from transformers import AutoTokenizer

    name = "ai4bharat/indic-parler-tts"
    model = ParlerTTSForConditionalGeneration.from_pretrained(name).to(device).eval()
    tok = AutoTokenizer.from_pretrained(name)
    desc_tok = AutoTokenizer.from_pretrained(model.config.text_encoder._name_or_path)
    out_sr = model.config.sampling_rate

    # Speakers in order of first appearance get voices in order.
    for ln in lines:
        if ln.speaker not in voice_map:
            voice_map[ln.speaker] = BENGALI_VOICES[len(voice_map) % len(BENGALI_VOICES)]
        ln.voice = voice_map[ln.speaker]

    clips_dir = work / "tts"
    clips_dir.mkdir(exist_ok=True)
    paths = []
    for i, ln in enumerate(lines):
        desc = (f"{ln.voice} speaks at a moderate pace with a clear, close-sounding "
                f"recording and no background noise.")
        d = desc_tok(desc, return_tensors="pt").to(device)
        p = tok(ln.bangla, return_tensors="pt").to(device)
        torch.manual_seed(1234)  # same seed every line -> more consistent voice
        with torch.no_grad():
            audio = model.generate(input_ids=d.input_ids, attention_mask=d.attention_mask,
                                   prompt_input_ids=p.input_ids,
                                   prompt_attention_mask=p.attention_mask)
        audio = audio.cpu().numpy().squeeze().astype(np.float32)
        path = clips_dir / f"{i:05d}.wav"
        sf.write(path, audio, out_sr)
        if out_sr != SR:  # normalise to the mixing rate
            fixed = load_audio(path, SR, 1)[:, 0]
            sf.write(path, fixed, SR)
        paths.append(path)
        print(f"  line {i + 1}/{len(lines)} [{ln.speaker}->{ln.voice}]", flush=True)
    return paths


def mix(lines: list[Line], clips: list[Path], background: Path, out_wav: Path,
        max_speedup: float = 1.35) -> None:
    bg = load_audio(background, SR, 2)
    track = bg * 0.9
    for i, (ln, clip) in enumerate(zip(lines, clips)):
        voice, _ = sf.read(clip, dtype="float32")
        if voice.ndim > 1:
            voice = voice.mean(axis=1)
        ln.tts_seconds = round(len(voice) / SR, 2)

        # Slot = until the next line starts (or the end of this line + 0.3 s at the end).
        next_start = lines[i + 1].start if i + 1 < len(lines) else ln.end + 0.3
        slot = max(next_start - ln.start, 0.3)
        if len(voice) / SR > slot:
            ln.stretch = round(min((len(voice) / SR) / slot, max_speedup), 3)
            voice = time_stretch(voice, SR, ln.stretch)

        start = int(ln.start * SR)
        ln.placed_at = ln.start
        end = min(start + len(voice), len(track))
        track[start:end] += voice[: end - start, None] * 1.0

    peak = np.abs(track).max()
    if peak > 1.0:
        track /= peak
    sf.write(out_wav, track, SR)


def write_outputs(video: Path, lines: list[Line], dubbed: Path, mux: bool) -> None:
    srt = video.with_suffix(".bn.srt")
    with open(srt, "w", encoding="utf-8") as f:
        for i, ln in enumerate(lines, 1):
            f.write(f"{i}\n{srt_time(ln.start)} --> {srt_time(ln.end)}\n{ln.bangla}\n\n")
    if mux:
        out = video.with_suffix(".bn.mkv")
        run(["ffmpeg", "-y", "-v", "error", "-i", str(video), "-i", str(dubbed),
             "-map", "0:v", "-map", "1:a", "-map", "0:a?", "-c:v", "copy", "-c:a", "aac",
             "-metadata:s:a:0", "language=ben", "-metadata:s:a:0", "title=Bangla",
             "-metadata:s:a:1", "title=Original", str(out)])
        print(f"  wrote {out}", flush=True)


# --------------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser(description="Offline Bangla dubbing spike")
    ap.add_argument("video", type=Path)
    ap.add_argument("--hf-token", default=os.environ.get("HF_TOKEN"),
                    help="Hugging Face token, needed once to download gated models")
    ap.add_argument("--offline", action="store_true", help="use cached models only, no network")
    ap.add_argument("--whisper", default="large-v3", help="large-v3 | turbo | medium | small")
    ap.add_argument("--lang", default=None, help="force source language code, e.g. en, hi, ko")
    ap.add_argument("--speakers", type=int, default=None, help="known number of speakers")
    ap.add_argument("--no-separation", action="store_true", help="skip Demucs (faster, loses music)")
    ap.add_argument("--no-mux", action="store_true", help="do not write the .bn.mkv video")
    args = ap.parse_args()

    if shutil.which("ffmpeg") is None:
        sys.exit("ffmpeg not found on PATH")
    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

    video = args.video.resolve()
    work = video.parent / f".{video.stem}.dubwork"
    work.mkdir(exist_ok=True)
    device = pick_device()
    print(f"device: {device}", flush=True)
    t = Timer()
    total0 = time.perf_counter()

    with t.stage("extract"):
        wav = extract_audio(video, work)
    if args.no_separation:
        vocals, background = wav, wav
        print("  (no separation: original audio will be ducked under the dub)")
    else:
        with t.stage("separate"):
            vocals, background = separate(wav, work, device)
    with t.stage("transcribe"):
        lines, lang = transcribe(vocals, device, args.whisper, args.lang)
    print(f"  {len(lines)} lines", flush=True)
    with t.stage("diarize"):
        diarize(vocals, lines, args.hf_token, device, args.speakers)
    with t.stage("translate"):
        translate(lines, device)
    voice_map: dict[str, str] = {}
    with t.stage("tts"):
        clips = synthesize(lines, work, device, voice_map)

    dubbed = video.with_suffix(".bn.wav")
    with t.stage("mix"):
        if args.no_separation:  # duck original speech instead of removing it
            bg = load_audio(wav, SR, 2) * 0.25
            sf.write(work / "ducked.wav", bg, SR)
            background = work / "ducked.wav"
        mix(lines, clips, background, dubbed)
    with t.stage("export"):
        write_outputs(video, lines, dubbed, mux=not args.no_mux)

    duration = sf.info(wav).duration
    total = time.perf_counter() - total0
    report = {
        "video": str(video), "device": device, "source_language": lang,
        "video_minutes": round(duration / 60, 2), "total_seconds": round(total, 1),
        "processing_min_per_video_min": round((total / 60) / max(duration / 60, 1e-6), 2),
        "stages_seconds": t.times, "speakers": voice_map,
        "lines_stretched": sum(1 for l in lines if l.stretch > 1.0),
        "lines_over_max_stretch": sum(1 for l in lines if l.stretch >= 1.35),
    }
    (work / "timings.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (work / "lines.json").write_text(
        json.dumps([asdict(l) for l in lines], ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"DONE: {dubbed}", flush=True)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
