"""
Spike prototype: minimal PyQt6 player for the dubbed output.

Plays a video with its Bangla track (<video>.bn.wav from dub_pipeline.py) and lets
you switch between Bangla and the original audio (BR-11) during playback.

Usage:
    python spike_player.py movie.mp4
"""
from __future__ import annotations

import locale
import sys
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (QApplication, QFileDialog, QHBoxLayout, QLabel, QMainWindow,
                             QPushButton, QSlider, QVBoxLayout, QWidget)

locale.setlocale(locale.LC_NUMERIC, "C")  # libmpv requires this before import
import mpv  # noqa: E402  (python-mpv; needs libmpv installed)


def fmt(t: float | None) -> str:
    t = int(t or 0)
    return f"{t // 3600:d}:{t % 3600 // 60:02d}:{t % 60:02d}"


class Player(QMainWindow):
    def __init__(self, video: Path | None):
        super().__init__()
        self.setWindowTitle("Bangla Dub Player (spike)")
        self.resize(1100, 680)

        self.screen_w = QWidget(self)
        self.screen_w.setAttribute(Qt.WidgetAttribute.WA_DontCreateNativeAncestors)
        self.screen_w.setAttribute(Qt.WidgetAttribute.WA_NativeWindow)
        self.screen_w.setStyleSheet("background:black")

        self.mpv = mpv.MPV(wid=str(int(self.screen_w.winId())), keep_open="yes",
                           input_default_bindings=True, input_vo_keyboard=True)

        self.play_btn = QPushButton("Pause")
        self.audio_btn = QPushButton("Audio: Bangla")
        self.sub_btn = QPushButton("Subtitles: off")
        open_btn = QPushButton("Open…")
        self.seek = QSlider(Qt.Orientation.Horizontal)
        self.seek.setRange(0, 1000)
        self.time_lbl = QLabel("0:00:00 / 0:00:00")

        self.play_btn.clicked.connect(self.toggle_play)
        self.audio_btn.clicked.connect(self.toggle_audio)
        self.sub_btn.clicked.connect(self.toggle_subs)
        open_btn.clicked.connect(self.pick_file)
        self.seek.sliderReleased.connect(self.do_seek)

        bar = QHBoxLayout()
        for w in (open_btn, self.play_btn, self.audio_btn, self.sub_btn):
            bar.addWidget(w)
        bar.addWidget(self.seek, 1)
        bar.addWidget(self.time_lbl)

        root = QVBoxLayout()
        root.addWidget(self.screen_w, 1)
        root.addLayout(bar)
        central = QWidget()
        central.setLayout(root)
        self.setCentralWidget(central)

        self.timer = QTimer(self, interval=250, timeout=self.tick)
        self.timer.start()
        self.bangla_on = True
        if video:
            self.load(video)

    # ------------------------------------------------------------------ actions
    def load(self, video: Path) -> None:
        self.video = video
        bn_audio = video.with_suffix(".bn.wav")
        bn_srt = video.with_suffix(".bn.srt")
        self.has_dub = bn_audio.exists()
        self.mpv.play(str(video))
        self.mpv.wait_for_property("duration", lambda v: v is not None, timeout=10)
        if self.has_dub:
            self.mpv.command("audio-add", str(bn_audio), "select", "Bangla", "ben")
        else:
            self.audio_btn.setText("No Bangla track")
            self.audio_btn.setEnabled(False)
        if bn_srt.exists():
            self.mpv.command("sub-add", str(bn_srt), "auto", "Bangla", "ben")
            self.mpv.sid = "no"
        self.setWindowTitle(f"{video.name} — Bangla Dub Player (spike)")

    def pick_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open video", "",
                                              "Video (*.mp4 *.mkv *.avi *.mov *.webm)")
        if path:
            self.load(Path(path))

    def toggle_play(self) -> None:
        self.mpv.pause = not self.mpv.pause
        self.play_btn.setText("Play" if self.mpv.pause else "Pause")

    def toggle_audio(self) -> None:
        tracks = [t for t in self.mpv.track_list if t["type"] == "audio"]
        bangla = next((t["id"] for t in tracks if t.get("title") == "Bangla"), None)
        original = next((t["id"] for t in tracks if t.get("title") != "Bangla"), None)
        self.bangla_on = not self.bangla_on
        self.mpv.aid = bangla if self.bangla_on else original
        self.audio_btn.setText("Audio: Bangla" if self.bangla_on else "Audio: Original")

    def toggle_subs(self) -> None:
        on = self.mpv.sid in (None, False, "no")
        self.mpv.sid = "auto" if on else "no"
        self.sub_btn.setText("Subtitles: on" if on else "Subtitles: off")

    def do_seek(self) -> None:
        if self.mpv.duration:
            self.mpv.seek(self.seek.value() / 1000 * self.mpv.duration, "absolute")

    def tick(self) -> None:
        pos, dur = self.mpv.time_pos, self.mpv.duration
        if dur and not self.seek.isSliderDown():
            self.seek.setValue(int((pos or 0) / dur * 1000))
        self.time_lbl.setText(f"{fmt(pos)} / {fmt(dur)}")

    def closeEvent(self, e) -> None:
        self.mpv.terminate()
        super().closeEvent(e)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = Player(Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None)
    w.show()
    sys.exit(app.exec())
