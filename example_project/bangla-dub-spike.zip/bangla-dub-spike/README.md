# Bangla Dub Spike

Prototype for step 3 (Spike / Feasibility) of the Offline Bangla Dubbing Video Player.

- `dub_pipeline.py` — dubs a video into Bangla in pre-process mode and writes
  `<video>.bn.wav`, `<video>.bn.srt` and `<video>.bn.mkv`, plus `timings.json` and
  `lines.json` in a hidden `.<video>.dubwork` folder for recording results.
- `spike_player.py` — PyQt6 + mpv player that plays the video with the Bangla track and
  switches between Bangla and original audio.

## 1. Install

System packages:

| OS | Command |
| --- | --- |
| Ubuntu / Debian | `sudo apt install ffmpeg libmpv-dev` |
| macOS | `brew install ffmpeg mpv` |
| Windows | Install ffmpeg and put `libmpv-2.dll` (from the mpv dev build) next to the script or on PATH |

Python 3.10–3.12:

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
# Install PyTorch for your hardware from https://pytorch.org/get-started/locally/
pip install -r requirements.txt
```

## 2. One-time model download (needs internet)

1. Create a Hugging Face account and a read token at https://huggingface.co/settings/tokens
2. Accept the conditions on these gated model pages while signed in:
   - https://huggingface.co/pyannote/speaker-diarization-3.1
   - https://huggingface.co/pyannote/segmentation-3.0
   - https://huggingface.co/ai4bharat/indic-parler-tts
   - https://huggingface.co/ai4bharat/indictrans2-en-indic-dist-200M
3. Run once on a short clip:

```bash
python dub_pipeline.py sample.mp4 --hf-token hf_xxx
```

Models are cached in `~/.cache/huggingface` (and `~/.cache/torch` for Demucs).

## 3. Offline runs (experiment E1)

Turn the network off, then:

```bash
python dub_pipeline.py clip.mp4 --offline
python spike_player.py clip.mp4
```

Useful options: `--speakers 3` when the count is known, `--whisper turbo` for speed,
`--lang hi` to force the source language, `--no-separation` to skip Demucs.

## 4. Recording results

- **E6 speed:** `timings.json` → `processing_min_per_video_min` and per-stage seconds.
- **E5 diarization:** `lines.json` → check each line's `speaker` against the video.
- **E7 sync:** `lines.json` → `stretch`; lines at the 1.35 cap may overrun their slot.
- **E2–E4 quality:** play the `.bn.mkv` to reviewers and score 1–5.

## Known limits of the spike

- Pre-process mode only; no live mode.
- Non-English sources go through Whisper's translate-to-English first (IndicTrans2 is
  English ↔ Indic only).
- faster-whisper and Demucs run on CPU on a Mac (no MPS backend); translation and TTS use MPS.
- Voices are Indic Parler-TTS's Indian-Bengali presets; Bangladeshi fine-tuning is a later phase.
- Not yet run against the real models: expect small API fixes on first run.
